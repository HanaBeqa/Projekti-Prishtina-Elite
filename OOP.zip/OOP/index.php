<?php
// Hapja e kodit PHP

declare(strict_types=1);
// Aktivizon strict types – PHP kërkon tipe të sakta (int, string, float)

require_once __DIR__ . '/classes/Database.php';
// Përfshin klasën Database (lidhja me databazë)

require_once __DIR__ . '/classes/Product.php';
// Përfshin klasën Product (CRUD për produktet)


// Krijon objektin Database
$db = new Database();

// Variabël që do të mbajë objektin Product
$productRepository = null;

// Variabël për ruajtjen e gabimeve të databazës
$dbError = '';

try {
    // Inicializon databazën (krijon DB dhe tabelën nëse nuk ekzistojnë)
    $db->initialize();

    // Krijon objektin Product dhe i jep lidhjen me databazë
    $productRepository = new Product($db->getConnection());
} catch (RuntimeException $exception) {
    // Nëse ndodh gabim gjatë lidhjes me databazë
    $dbError = $exception->getMessage();
}

// Merr veprimin (action) nga POST ose GET
$action = $_POST['action'] ?? $_GET['action'] ?? '';

// Mesazh suksesi
$message = '';

// Mesazh gabimi
$error = '';


// ================= CREATE =================
// Kontrollon nëse po krijohet produkt i ri
if ($productRepository && $action === 'create' && $_SERVER['REQUEST_METHOD'] === 'POST') {

    // Merr dhe pastron të dhënat nga forma
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price = (float) ($_POST['price'] ?? 0);
    $stock = (int) ($_POST['stock'] ?? 0);

    // Validim i thjeshtë
    if ($name === '' || $description === '') {
        $error = 'Name and description are required.';
    } else {
        // Thirr metodën create() nga klasa Product
        $productRepository->create($name, $description, $price, $stock);
        $message = 'Product created successfully.';
    }
}


// ================= UPDATE =================
// Kontrollon nëse po përditësohet produkti
if ($productRepository && $action === 'update' && $_SERVER['REQUEST_METHOD'] === 'POST') {

    // Merr ID dhe të dhënat e reja nga forma
    $id = (int) ($_POST['id'] ?? 0);
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price = (float) ($_POST['price'] ?? 0);
    $stock = (int) ($_POST['stock'] ?? 0);

    // Kontrollon nëse të dhënat janë valide
    if ($id > 0 && $name !== '' && $description !== '') {
        // Thirr metodën update()
        $productRepository->update($id, $name, $description, $price, $stock);
        $message = 'Product updated successfully.';
    } else {
        $error = 'Please complete the form before updating.';
    }
}


// ================= DELETE =================
// Kontrollon nëse po fshihet produkti
if ($productRepository && $action === 'delete') {

    // Merr ID nga URL (GET)
    $id = (int) ($_GET['id'] ?? 0);

    if ($id > 0) {
        // Thirr metodën delete()
        $productRepository->delete($id);
        $message = 'Product deleted successfully.';
    }
}


// ================= EDIT =================
// Merr një produkt për editim
$editProduct = null;

if ($productRepository && $action === 'edit') {

    // Merr ID nga URL
    $id = (int) ($_GET['id'] ?? 0);

    if ($id > 0) {
        // Thirr metodën find() për ta marrë produktin
        $editProduct = $productRepository->find($id);
    }
}


// Merr listën e produkteve (READ)
$products = $productRepository ? $productRepository->all() : [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <!-- Meta për responsive design -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>ProjektAI Products</title>

    <!-- Përfshin CSS -->
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <div class="page">

        <!-- HEADER -->
        <header class="hero">
            <div>
                <p class="eyebrow">PANELI I ADMINISTRATORIT</p>
                <h1>CRUD</h1>
                <p class="subtitle">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
            </div>

            <!-- STATISTIKA -->
            <div class="card stats">
                <div>
                    <span class="stat-label">Totali i produkteve</span>
                    <span class="stat-value"><?php echo count($products); ?></span>
                </div>
                <div>
                    <span class="stat-label">Emri i Databazes</span>
                    <span class="stat-value">projektai_crud</span>
                </div>
            </div>
        </header>

        <!-- MESAZHET -->
        <?php if ($dbError !== ''): ?>
            <div class="notice error">
                Lidhja me databazen deshtoi. Shiko XAMPP MySQL dhe credentials.
            </div>
        <?php endif; ?>

        <?php if ($message !== ''): ?>
            <div class="notice success">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <?php if ($error !== ''): ?>
            <div class="notice error">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <!-- GRID -->
        <section class="grid">

            <!-- FORMA -->
            <div class="card form-card">
                <h2>
                    <?php echo $editProduct ? 'Edit product' : 'Add a new product'; ?>
                </h2>

                <p class="muted">Pershkruaj produktin tend</p>

                <form method="post" class="product-form">

                    <!-- Action i fshehur -->
                    <input type="hidden" name="action"
                           value="<?php echo $editProduct ? 'update' : 'create'; ?>">

                    <!-- ID e fshehur kur editohet -->
                    <?php if ($editProduct): ?>
                        <input type="hidden" name="id"
                               value="<?php echo (int) $editProduct['id']; ?>">
                    <?php endif; ?>

                    <label>
                        Emri i produktit
                        <input type="text" name="name"
                               value="<?php echo htmlspecialchars($editProduct['name'] ?? ''); ?>"
                               required>
                    </label>

                    <label>
                        Pershkrimi i produktit
                        <textarea name="description" rows="4" required>
<?php echo htmlspecialchars($editProduct['description'] ?? ''); ?>
                        </textarea>
                    </label>

                    <div class="two-columns">
                        <label>
                            Çmimi (€)
                            <input type="number" name="price" step="0.01" min="0"
                                   value="<?php echo htmlspecialchars((string) ($editProduct['price'] ?? '0.00')); ?>">
                        </label>

                        <label>
                            Stock
                            <input type="number" name="stock" min="0"
                                   value="<?php echo htmlspecialchars((string) ($editProduct['stock'] ?? '0')); ?>">
                        </label>
                    </div>

                    <button type="submit" class="primary">
                        <?php echo $editProduct ? 'Update product' : 'Create product'; ?>
                    </button>

                    <?php if ($editProduct): ?>
                        <a class="ghost" href="index.php">Cancel</a>
                    <?php endif; ?>
                </form>
            </div>

            <!-- LISTA -->
            <div class="card list-card">
                <h2>Lista e produkteve</h2>

                <?php if (count($products) === 0): ?>
                    <p>Ska asnje produkt.</p>
                <?php else: ?>
                    <?php foreach ($products as $product): ?>
                        <div class="product-item">
                            <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                            <p><?php echo htmlspecialchars($product['description']); ?></p>
                            <p>
                                €<?php echo number_format((float) $product['price'], 2); ?>
                                | <?php echo (int) $product['stock']; ?> ne stock
                            </p>
                            <a href="?action=edit&id=<?php echo (int) $product['id']; ?>">Edito</a>
                            <a href="?action=delete&id=<?php echo (int) $product['id']; ?>"
                               onclick="return confirm('Delete this product?');">
                               Fshi
                            </a>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

        </section>
    </div>
</body>
</html>
