<?php
// Hapja e kodit PHP

declare(strict_types=1);
// Aktivizon strict types
// PHP kontrollon që tipet e të dhënave (int, string, float) të jenë të sakta

class Product
{
    // Variabël private që ruan lidhjen me databazë
    private mysqli $connection;

    public function __construct(mysqli $connection)
    {
        // Constructor që pranon lidhjen me databazë
        // Kjo lidhje ruhet në variablën $connection
        $this->connection = $connection;
    }

    public function all(): array
    {
        // Merr të gjitha produktet nga tabela products
        // Renditja bëhet nga më i riu tek më i vjetri
        $result = $this->connection->query(
            'SELECT * FROM products ORDER BY created_at DESC'
        );

        // Nëse query dështon, kthehet array bosh
        if (!$result) {
            return [];
        }

        // fetch_all(MYSQLI_ASSOC) kthen të gjitha rreshtat
        // si array asociativ
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function find(int $id): ?array
    {
        // Përgatit SQL query me placeholder (?)
        // Përdoret për siguri kundër SQL Injection
        $statement = $this->connection->prepare(
            'SELECT * FROM products WHERE id = ?'
        );

        // Lidhet parametri me placeholder-in
        // 'i' do të thotë integer
        $statement->bind_param('i', $id);

        // Ekzekuton query-n
        $statement->execute();

        // Merr rezultatin e query-së
        $result = $statement->get_result();

        // Merr një rresht të vetëm si array asociativ
        $product = $result->fetch_assoc();

        // Mbyll prepared statement
        $statement->close();

        // Nëse produkti ekziston, kthehet array
        // përndryshe kthehet null
        return $product ?: null;
    }

    public function create(
        string $name,
        string $description,
        float $price,
        int $stock
    ): void {
        // Përgatit SQL query për INSERT
        $statement = $this->connection->prepare(
            'INSERT INTO products (name, description, price, stock) 
             VALUES (?, ?, ?, ?)'
        );

        // Lidhen parametrat me query-n
        // s = string
        // s = string
        // d = double (float)
        // i = integer
        $statement->bind_param(
            'ssdi',
            $name,
            $description,
            $price,
            $stock
        );

        // Ekzekuton INSERT query
        $statement->execute();

        // Mbyll prepared statement
        $statement->close();
    }

    public function update(
        int $id,
        string $name,
        string $description,
        float $price,
        int $stock
    ): void {
        // Përgatit SQL query për UPDATE
        $statement = $this->connection->prepare(
            'UPDATE products 
             SET name = ?, description = ?, price = ?, stock = ? 
             WHERE id = ?'
        );

        // Lidhen parametrat me query-n
        // s = string
        // s = string
        // d = double
        // i = integer
        // i = integer (id)
        $statement->bind_param(
            'ssdii',
            $name,
            $description,
            $price,
            $stock,
            $id
        );

        // Ekzekuton UPDATE query
        $statement->execute();

        // Mbyll prepared statement
        $statement->close();
    }

    public function delete(int $id): void
    {
        // Përgatit SQL query për DELETE
        $statement = $this->connection->prepare(
            'DELETE FROM products WHERE id = ?'
        );

        // Lidhet id si integer
        $statement->bind_param('i', $id);

        // Ekzekuton DELETE query
        $statement->execute();

        // Mbyll prepared statement
        $statement->close();
    }
}
