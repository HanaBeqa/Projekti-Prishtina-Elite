<?php
// Tregon që po fillon kodi PHP

declare(strict_types=1);
// Aktivizon kontrollin strikt të tipeve (string, int, float, etj.)
// PHP nuk lejon që një tip i gabuar të përdoret në metoda ose variabla

class Database
{
    // Variabla private për ruajtjen e të dhënave të lidhjes me databazë

    private string $host;
    // Adresa e serverit të databazës (zakonisht localhost ose 127.0.0.1)

    private string $user;
    // Emri i përdoruesit të databazës (p.sh. root)

    private string $password;
    // Fjalëkalimi i databazës

    private string $database;
    // Emri i databazës që do të përdoret

    private ?mysqli $connection = null;
    // Variabël që ruan lidhjen me databazë
    // ?mysqli do të thotë që mund të jetë mysqli ose null
    // Fillimisht është null sepse ende nuk ka lidhje

    public function __construct()
    {
        // Merr vlerën e DB_HOST nga environment variable
        // Nëse nuk ekziston, përdoret '127.0.0.1'
        $this->host = getenv('DB_HOST') ?: '127.0.0.1';

        // Merr DB_USER nga environment variable
        // Nëse nuk ekziston, përdoret 'root'
        $this->user = getenv('DB_USER') ?: 'root';

        // Merr DB_PASSWORD nga environment variable
        // Nëse nuk ekziston, përdoret string bosh
        $this->password = getenv('DB_PASSWORD') ?: '';

        // Merr DB_NAME nga environment variable
        // Nëse nuk ekziston, përdoret 'projektai_crud'
        $this->database = getenv('DB_NAME') ?: 'projekti_ueb';
    }

    public function getConnection(): mysqli
    {
        // Kontrollon nëse lidhja me databazë ekziston tashmë
        // Nëse po, kthehet ajo lidhje pa krijuar të re
        if ($this->connection instanceof mysqli) {
            return $this->connection;
        }

        // Krijon lidhje të re me databazë (pa zgjedhur databazën ende)
        $this->connection = new mysqli(
            $this->host,
            $this->user,
            $this->password
        );

        // Kontrollon nëse ka ndodhur gabim gjatë lidhjes
        if ($this->connection->connect_error) {
            // Nëse po, ndalet ekzekutimi dhe shfaqet mesazhi i gabimit
            throw new RuntimeException(
                'Database connection failed: ' . $this->connection->connect_error
            );
        }

        // Kthen lidhjen e krijuar me sukses
        return $this->connection;
    }

    public function initialize(): void
    {
        // Merr lidhjen me databazë
        $connection = $this->getConnection();

        // Siguron emrin e databazës nga SQL Injection
        $databaseName = $connection->real_escape_string($this->database);

        // Krijon databazën nëse nuk ekziston
        $connection->query(
            "CREATE DATABASE IF NOT EXISTS `{$databaseName}` 
             CHARACTER SET utf8mb4 
             COLLATE utf8mb4_unicode_ci"
        );

        // Zgjedh databazën për përdorim
        $connection->select_db($this->database);

        // SQL për krijimin e tabelës products
        $createTableSql = <<<SQL
CREATE TABLE IF NOT EXISTS products (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    stock INT UNSIGNED NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB
SQL;

        // Ekzekuton query për krijimin e tabelës
        $connection->query($createTableSql);
    }
}
